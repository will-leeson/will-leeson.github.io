#include "Shape.hpp"

int Shape::get_x_cor(){
    return x_cor;
}

int Shape::get_y_cor(){
    return y_cor;
}

std::string Shape::get_color(){
    return color;
}

void Shape::set_x_cor(int new_x){
    x_cor = new_x;
}

void Shape::set_y_cor(int new_y){
    y_cor = new_y;
}

void Shape::set_color(std::string new_color){
    color = new_color;
}

std::string Shape::to_string(){
    return color + " Shape";
};
#include <iostream>

#include "Shape.hpp"
#include "Circle.hpp"
#include "Rectangle.hpp"

int main(){
    Circle circle1(0, 0, "Green", 2);
    Circle circle2(2, 2, "Yellow", 1);
    Rectangle rectangle1(5, 5, "Teal", 2,3);
    Rectangle rectangle2 = rectangle1*2;


    Shape* my_shapes[] = {&circle1, &circle2, &rectangle1, &rectangle2};

    for(int i=0; i<4; i++){
        std::cout << my_shapes[i]->get_area() << std::endl;
    }
    
    return 0;
}


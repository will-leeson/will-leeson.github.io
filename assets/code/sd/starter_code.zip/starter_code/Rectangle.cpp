#include "Rectangle.hpp"

int Rectangle::get_base(){
    return base;
}

int Rectangle::get_height(){
    return height;
}

void Rectangle::set_base(int new_base){
    base = new_base;
}

void Rectangle::set_height(int new_height){
    height = new_height;
}

std::string Rectangle::to_string(){
    return color + " Rectangle";
}

double Rectangle::get_area(){
    return base*height;
}

Rectangle operator*(Rectangle r1, int scale){
    Rectangle new_r(r1.get_x_cor(), r1.get_y_cor(), r1.get_color(), r1.get_base()*scale, r1.get_height()*scale);

    return new_r;
}

Rectangle operator*(int scale, Rectangle r1){
    return r1 * scale;
}

void Rectangle::operator++(){
    base = base + 1;
    height = height + 1;
}
#ifndef RECTANGLE_HPP
#define RECTANGLE_HPP

#include "Shape.hpp"

class Rectangle : public Shape {
public:
    Rectangle(int x, int y, std::string color, int b, int h) : Shape(x, y, color), base(b), height(h) {};

    int get_base();
    int get_height();

    void set_base(int new_base);
    void set_height(int new_height);

    std::string to_string();
    
    double get_area();

    void operator++();
private:
    int base;
    int height;
};

Rectangle operator*(Rectangle r1, int scale);
Rectangle operator*(int scale, Rectangle r1);

#endif

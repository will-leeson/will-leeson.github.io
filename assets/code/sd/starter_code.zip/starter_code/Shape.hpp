#ifndef SHAPE_HPP
#define SHAPE_HPP

#include <string>

class Shape{
public:
    Shape(int x, int y, std::string a_color) : x_cor(x), y_cor(y), color(a_color) {};

    int get_x_cor();
    int get_y_cor();
    std::string get_color();

    void set_x_cor(int new_x);
    void set_y_cor(int new_y);
    void set_color(std::string new_color);

    virtual std::string to_string();
    virtual double get_area() = 0;
protected:    
    int x_cor;
    int y_cor;
    std::string color;
};

#endif


#include "Circle.hpp"

int Circle::get_radius(){
    return radius;
}

void Circle::set_radius(int new_r){
    radius = new_r;
}

std::string Circle::to_string(){
    return color + " Circle";
}

double Circle::get_area(){
    return 3.1415 * radius * radius;
}

void Circle::operator=(const Circle &c){
    radius = c.radius;

    color = c.color;
    x_cor = c.x_cor;
    y_cor = c.y_cor;
}


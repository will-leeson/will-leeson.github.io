#ifndef CIRCLE_HPP
#define CIRCLE_HPP

#include "Shape.hpp"

class Circle : public Shape {
public:
    Circle(int x, int y, std::string color, int r) : Shape(x,y,color), radius(r) {};

    int get_radius();
    void set_radius(int new_r);

    std::string to_string();
    
    double get_area();

    void operator=(const Circle &c);

private:
    int radius;
};

#endif


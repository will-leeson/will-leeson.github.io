#ifndef BANKACCOUNT_HPP
#define BANKACCOUNT_HPP

#include <string>

class BankAccount {
public:
    BankAccount(std::string first, std::string last, double initBalance);
    BankAccount(std::string first, std::string last);

    double get_balance();
    std::string get_first_name();
    std::string get_last_name();

    void set_first_name(std::string name);
    void set_last_name(std::string name);

    bool withdrawal(double amount);
    bool deposit(double amount);

    virtual std::string to_string() = 0;

    virtual ~BankAccount() {};

private:
    std::string first_name;
    std::string last_name;
    double balance;
};

#endif
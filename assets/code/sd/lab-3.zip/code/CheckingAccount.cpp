#include "CheckingAccount.hpp"

CheckingAccount::CheckingAccount(std::string first, std::string last, double initBalance) : BankAccount(first, last, initBalance) {
    check_log = std::list<double>();
}

CheckingAccount::CheckingAccount(std::string first, std::string last) : BankAccount(first, last) {
    check_log = std::list<double>();
}

bool CheckingAccount::write_check(BankAccount &a, double amount){
    bool success = withdrawal(amount);

    if(success){
        a.deposit(amount);
        check_log.push_back(amount);
    }

    return success;
}

std::string CheckingAccount::to_string(){
    return "Checking Account Balance: $" + std::to_string(get_balance()) + ", checks written: " + std::to_string(check_log.size());
}

std::list<double> CheckingAccount::get_check_log(){
    return check_log;
}
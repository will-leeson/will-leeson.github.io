#ifndef SAVINGSACCOUNT_HPP
#define SAVINGSACCOUNT_HPP

#include "BankAccount.hpp"

class SavingsAccount : public BankAccount {
public:
    SavingsAccount(std::string first, std::string last, double initBalance, double interest);
    SavingsAccount(std::string first, std::string last, double interest);

    double get_interest_rate();

    void set_interest_rate(double interest);

    void accrue_interest();

    std::string to_string();

private:
    double interest_rate;
};

#endif
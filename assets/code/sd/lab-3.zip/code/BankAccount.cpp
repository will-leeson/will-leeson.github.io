#include "BankAccount.hpp"
#include <iostream>

BankAccount::BankAccount(std::string first, std::string last, double initBalance){
    first_name = first;
    last_name = last;
    balance = initBalance;
}

BankAccount::BankAccount(std::string first, std::string last){
    first_name = first;
    last_name = last;
    balance = 0;
}

double BankAccount::get_balance(){
    return balance;
}

std::string BankAccount::get_first_name(){
    return first_name;
}

std::string BankAccount::get_last_name(){
    return last_name;
}

void BankAccount::set_first_name(std::string name){
    first_name = name;
}

void BankAccount::set_last_name(std::string name){
    last_name = name;
}

bool BankAccount::withdrawal(double amount){
    if(amount > 0){
        if(amount <= balance){
            balance = balance - amount;
            return true;
        }
        else {
            std::cout << "Withdrawal amount greater than balance." << std::endl;
            return false;
        }
    }
    else {
        std::cout << "Invalid amount to withdrawal. Must be positive."<<std::endl;
        return false;
    }
}

bool BankAccount::deposit(double amount){
    if(amount > 0){
        balance = balance + amount;
        return true;
    }
    else {
        std::cout << "Invalid amount to deposit. Must be positive." << std::endl;
        return false;
    }
}
#ifndef CHECKINGACCOUNT_HPP
#define CHECKINGACCOUNT_HPP

#include "BankAccount.hpp"
#include <list>

class CheckingAccount : public BankAccount {
public:
    CheckingAccount(std::string first, std::string last, double initBalance);
    CheckingAccount(std::string first, std::string last);

    bool write_check(BankAccount &a, double amount);

    std::string to_string();

    std::list<double> get_check_log();

private:
    std::list<double> check_log;
};

#endif
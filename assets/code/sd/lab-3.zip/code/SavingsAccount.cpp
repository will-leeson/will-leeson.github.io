#include "SavingsAccount.hpp"

SavingsAccount::SavingsAccount(std::string first, std::string last, double initBalance, double interest) : BankAccount(first, last, initBalance){
    interest_rate = interest;
}

SavingsAccount::SavingsAccount(std::string first, std::string last, double interest) : BankAccount(first, last){
    interest_rate = interest;
}

void SavingsAccount::accrue_interest(){
    double interest = interest_rate * get_balance();
    deposit(interest);
}

std::string SavingsAccount::to_string(){
    return "Savings Account Balance: $" + std::to_string(get_balance()) + ", Interest Rate: "+std::to_string(interest_rate);
}

double SavingsAccount::get_interest_rate(){
    return interest_rate;
}

void SavingsAccount::set_interest_rate(double interest){
    interest_rate = interest;
}
#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MAIN

#include <boost/test/unit_test.hpp>
#include "Calculator.hpp"

BOOST_AUTO_TEST_SUITE(calculator_suite)

BOOST_AUTO_TEST_SUITE_END()
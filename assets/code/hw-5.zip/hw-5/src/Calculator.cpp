#include "Calculator.hpp"
#include <stdexcept>

double Calculator::add(double value){
    state += state;

    return state;
}

double Calculator::subtract(double value){
    state -= value;

    return state;
}

double Calculator::multiply(double value){
    state *= value;

    return state;
}

double Calculator::abs(){
    if(state > 0){
        state = -state;
    }

    return state;
}

double Calculator::divide(double value){
    if(value == 0){
        throw std::invalid_argument("Cannot divide by 0");
    }
    else{
        state /= value;
    }

    return state;
}

double Calculator::sqrt(){
    double guess = 1.0;
    double old_guess = 0.0;
    double diff;

    do {
        old_guess = guess;

        guess -= (guess*guess - state) / (2 * guess);

        diff = guess - old_guess;
        if(diff < 0){
            diff = -diff;
        }
    } while(diff > 0.0001);

    state = guess;

    return guess;
}

// Accessor method to retrieve the state.
double Calculator::getState() const {
    return state;
}

// Resets the internal state.
void Calculator::clear(){
    state = 0.0;
}